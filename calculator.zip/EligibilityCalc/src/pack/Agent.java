package pack;

public class Agent {

	private int ID;
	private double share;
	private Date policyDate;
	private boolean isEligable;
	
	
	public Agent(int ID, double share, Date theDate) {
		
	}

}
